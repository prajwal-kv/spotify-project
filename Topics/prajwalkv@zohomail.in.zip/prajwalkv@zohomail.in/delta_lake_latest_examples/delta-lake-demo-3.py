# Databricks notebook source
# MAGIC %sql
# MAGIC USE CATALOG deltalake_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS databricks_delta_lake_transactions_logs.default.orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE orders_ext_01 (
# MAGIC order_id BIGINT,
# MAGIC sku STRING,
# MAGIC product_name STRING,
# MAGIC product_category STRING,
# MAGIC qty INT,
# MAGIC unit_price DECIMAL(10,2)
# MAGIC )
# MAGIC LOCATION 'abfss://externaldata@newgeneration.dfs.core.windows.net/orders'
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO orders_ext_01
# MAGIC (order_id, sku, product_name, product_category, qty, unit_price)
# MAGIC VALUES
# MAGIC (1, 'SKU-1001', 'Wireless Mouse', 'Electronics', 2, 799.00),
# MAGIC (2, 'SKU-2001', 'Yoga Mat', 'Fitness', 1, 1199.00),
# MAGIC (3, 'SKU-3001', 'Notebook A5', 'Stationery', 5, 49.50),
# MAGIC (4, 'SKU-4001', 'Coffee Mug', 'Kitchen', 3, 299.00),
# MAGIC (5, 'SKU-5001', 'LED Bulb', 'Electronics', 4, 149.99);

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE DETAIL deltalake_catalog.default.orders_ext_01;

# COMMAND ----------

display(dbutils.fs.ls('abfss://externaldata@newgeneration.dfs.core.windows.net/orders'))

# COMMAND ----------

display(dbutils.fs.ls('abfss://externaldata@newgeneration.dfs.core.windows.net/orders/_delta_log'))

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * from JSON.`abfss://externaldata@newgeneration.dfs.core.windows.net/orders/_delta_log/00000000000000000000.json`

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY deltalake_catalog.default.orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * from JSON.`abfss://externaldata@newgeneration.dfs.core.windows.net/orders/_delta_log/00000000000000000001.json`

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE FORMATTED deltalake_catalog.default.orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT OVERWRITE deltalake_catalog.default.orders_ext_01
# MAGIC (order_id, sku, product_name, product_category, qty, unit_price)
# MAGIC VALUES (8, 'SKU-1008', 'Wireless Mouse', 'Electronics', 8, 788.00);

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from deltalake_catalog.default.orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * from JSON.`abfss://externaldata@newgeneration.dfs.core.windows.net/orders/_delta_log/00000000000000000002.json`

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY deltalake_catalog.default.orders_ext_01;

# COMMAND ----------

# MAGIC %sql DROP TABLE deltalake_catalog.default.orders_ext_01

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE orders_ext_01 (
# MAGIC order_id BIGINT,
# MAGIC sku STRING,
# MAGIC product_name STRING,
# MAGIC product_category STRING,
# MAGIC qty INT,
# MAGIC unit_price DECIMAL(10,2)
# MAGIC )
# MAGIC LOCATION 'abfss://externaldata@newgeneration.dfs.core.windows.net/orders'
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO deltalake_catalog.default.orders_ext_01
# MAGIC (order_id, sku, product_name, product_category, qty, unit_price)
# MAGIC VALUES
# MAGIC (11, 'SKU-1001', 'Wireless Mouse', 'Electronics', 2, 799.00),
# MAGIC (12, 'SKU-2001', 'Yoga Mat', 'Fitness', 1, 1199.00),
# MAGIC (13, 'SKU-3001', 'Notebook A5', 'Stationery', 5, 49.50)

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO orders_ext_01
# MAGIC (order_id, sku, product_name, product_category, qty, unit_price)
# MAGIC VALUES
# MAGIC (13, 'SKU-1001', 'Wireless Mouse', 'Electronics', 2, 799.00),
# MAGIC (14, 'SKU-2001', 'Yoga Mat', 'Fitness', 1, 1199.00);
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY orders_ext_01;

# COMMAND ----------

# MAGIC %md
# MAGIC Deleting scenario

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM orders_ext_01 WHERE order_id = 3;
# MAGIC     
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from databricks_delta_lake_transactions_logs.default.orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM orders_ext_01 WHERE order_id = 13;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from deltalake_catalog.default.orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM orders_ext_01 WHERE order_id = 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from deltalake_catalog.default.orders_ext_01;

# COMMAND ----------

display(dbutils.fs.ls('abfss://externaldata@newgeneration.dfs.core.windows.net/orders/_delta_log'))

# COMMAND ----------

display(dbutils.fs.ls('abfss://externaldata@newgeneration.dfs.core.windows.net/orders'))

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM orders_ext_01 WHERE order_id IN (1,4);

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC DROP TABLE deltalake_catalog.default.orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE orders_ext_01 (
# MAGIC order_id BIGINT,
# MAGIC sku STRING,
# MAGIC product_name STRING,
# MAGIC product_category STRING,
# MAGIC qty INT,
# MAGIC unit_price DECIMAL(10,2)
# MAGIC )
# MAGIC LOCATION 'abfss://externaldata@newgeneration.dfs.core.windows.net/orders'
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO orders_ext_01
# MAGIC (order_id, sku, product_name, product_category, qty, unit_price)
# MAGIC VALUES
# MAGIC (1, 'SKU-1001', 'Wireless Mouse', 'Electronics', 2, 799.00),
# MAGIC (2, 'SKU-2001', 'Yoga Mat', 'Fitness', 1, 1199.00),
# MAGIC (3, 'SKU-3001', 'Notebook A5', 'Stationery', 5, 49.50)
# MAGIC

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC INSERT INTO orders_ext_01
# MAGIC (order_id, sku, product_name, product_category, qty, unit_price)
# MAGIC VALUES
# MAGIC
# MAGIC (4, 'SKU-4001', 'Coffee Mug', 'Kitchen', 3, 299.00),
# MAGIC (5, 'SKU-5001', 'LED Bulb', 'Electronics', 4, 149.99);

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from orders_ext_01;

# COMMAND ----------

# MAGIC %sql OPTIMIZE orders_ext_01

# COMMAND ----------

# MAGIC %sql 
# MAGIC VACUUM orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM orders_ext_01 RETAIN 0 HOURS DRY RUN;

# COMMAND ----------

# MAGIC %md
# MAGIC Update scenario

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE orders_ext_01 SET unit_price = 1000.00 WHERE order_id = 1;
# MAGIC   

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY orders_ext_01;
# MAGIC     
# MAGIC

# COMMAND ----------

