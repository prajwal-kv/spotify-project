# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog deltalake_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS orders_managed;
# MAGIC
# MAGIC CREATE OR REPLACE TABLE orders_managed (
# MAGIC order_id BIGINT,
# MAGIC sku STRING,
# MAGIC product_name STRING,
# MAGIC product_category STRING,
# MAGIC qty INT,
# MAGIC unit_price DECIMAL(10,2)
# MAGIC );
# MAGIC
# MAGIC ALTER TABLE orders_managed ADD CONSTRAINT valid_qty CHECK (qty > 0);

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO orders_managed VALUES
# MAGIC   (1, 'SKU-1001', 'Wireless Mouse', 'Electronics', 2, 799.00),
# MAGIC   (2, 'SKU-2001', 'Yoga Mat', 'Fitness', 1, 1199.00),
# MAGIC   (3, 'SKU-3001', 'Notebook A5', 'Stationery', 5, 49.50),
# MAGIC   (4, 'SKU-4001', 'Coffee Mug', 'Kitchen', 3, 299.00),
# MAGIC   (5, 'SKU-5001', 'LED Bulb', 'Electronics', 4, 149.99);

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO orders_managed VALUES
# MAGIC   (6, 'SKU-6001', 'Bluetooth Headphones', 'Electronics', 1, 2599.00),
# MAGIC   (7, 'SKU-7001', 'Running Shoes', 'Fitness', 2, 3499.00),
# MAGIC   (8, 'SKU-8001', 'Ballpoint Pen Pack', 'Stationery', 10, 99.00)

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM orders_managed
# MAGIC WHERE order_id = 4;

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE orders_managed
# MAGIC SET qty = 3,
# MAGIC unit_price = 3299.00
# MAGIC WHERE order_id = 7;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY orders_managed

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO orders_managed VALUES
# MAGIC   (9, 'SKU-9001', 'Stainless Steel Bottle', 'Kitchen', 2, 499.00),
# MAGIC   (10, 'SKU-1002', 'Smart Watch', 'Electronics', 1, 7499.00)

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY orders_managed

# COMMAND ----------

# MAGIC %sql
# MAGIC describe detail orders_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from orders_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT _metadata.file_path FROM orders_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS orders_managed_dclone;
# MAGIC
# MAGIC CREATE OR REPLACE TABLE orders_managed_dclone DEEP CLONE orders_managed;
# MAGIC DESCRIBE DETAIL orders_managed_dclone;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from orders_managed_dclone order by order_id

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from orders_managed order by order_id

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT _metadata.file_path FROM orders_managed_dclone;

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO orders_managed VALUES
# MAGIC   (11, 'SKU-1101', 'Resistance Bands Set', 'Fitness', 1, 899.00),
# MAGIC   (12, 'SKU-1201', 'Sticky Notes Pack', 'Stationery', 6, 59.00)

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history orders_managed

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history orders_managed_dclone

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO orders_managed_dclone VALUES
# MAGIC   (13, 'SKU-1301', 'Non-stick Frying Pan', 'Kitchen', 1, 1299.00)

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM orders_managed_sclone
# MAGIC WHERE order_id = 3;

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history orders_managed_sclone

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM orders_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from orders_managed

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM orders_managed RETAIN 0 HOURS DRY RUN;

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE orders_managed
# MAGIC SET TBLPROPERTIES(
# MAGIC   'delta.deletedFileRetentionDuration' = 'interval 0 hours'
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM orders_managed DRY RUN;

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM orders_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from orders_managed_dclone order by order_id;

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history orders_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from orders_managed@v6

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct _metadata.file_path from orders_managed@v9

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM orders_managed_sclone;

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE orders_managed_sclone
# MAGIC SET TBLPROPERTIES(
# MAGIC   'delta.deletedFileRetentionDuration' = 'interval 0 hours'
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM orders_managed_sclone DRY RUN;

# COMMAND ----------

# MAGIC %sql
# MAGIC restore table orders_managed version as of 8;

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table orders_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC create table orders_copynew as 
# MAGIC select * from orders_managed_dclone;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from orders_copynew;

# COMMAND ----------

# MAGIC %sql
# MAGIC describe formatted orders_copynew;

# COMMAND ----------

