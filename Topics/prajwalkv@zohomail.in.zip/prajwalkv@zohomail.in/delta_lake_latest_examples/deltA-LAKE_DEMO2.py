# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC USE CATALOG deltalake_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE orders_managed (
# MAGIC order_id BIGINT,
# MAGIC sku STRING,
# MAGIC product_name STRING,
# MAGIC product_category STRING,
# MAGIC qty INT,
# MAGIC unit_price DECIMAL(10,2)
# MAGIC ) USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC create volume if not exists deltalake_catalog.default.delta_volume1;
# MAGIC     
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Create a folder inside a volume(Captial V in code)

# COMMAND ----------

# Correct path format for Unity Catalog volumes
dbutils.fs.mkdirs('/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1')

# COMMAND ----------

# MAGIC %fs ls /Volumes/deltalake_catalog/default/delta_volume1

# COMMAND ----------

# MAGIC %md
# MAGIC Create a df in delta formate in ordersdata1(volume)

# COMMAND ----------

# Orders sample data
data = [
    (1, "SKU-1001", "Wireless Mouse", "Electronics", 2, 799.00),
    (2, "SKU-2001", "Yoga Mat", "Fitness", 1, 1199.00),
    (3, "SKU-3001", "Notebook A5", "Stationery", 5, 49.50),
    (4, "SKU-4001", "Coffee Mug", "Kitchen", 3, 299.00),
    (5, "SKU-5001", "LED Bulb", "Electronics", 4, 149.99)
]


# COMMAND ----------

columns = ["order_id", "sku", "product_name", "product_category", "qty", "unit_price"]

# COMMAND ----------

# Create DataFrame
df = spark.createDataFrame(data, columns)

# COMMAND ----------


# Display DataFrame
display(df)

# COMMAND ----------

volume_path = "/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1"
df.write.format("delta").save(volume_path)


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE DETAIL delta.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE FORMATTED delta.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`

# COMMAND ----------

# MAGIC %fs ls /Volumes/deltalake_catalog/default/delta_volume1/ordersdata1

# COMMAND ----------

# MAGIC %fs ls /Volumes/deltalake_catalog/default/delta_volume1/ordersdata1/_delta_log

# COMMAND ----------

log_file_path ="dbfs:/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1/_delta_log/00000000000000000000.json"

# COMMAND ----------

df_log = spark.read.json(log_file_path)
display(df_log)

# COMMAND ----------

# MAGIC %md
# MAGIC SQL Style

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * from JSON.`dbfs:/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1/_delta_log/00000000000000000000.json`

# COMMAND ----------

# MAGIC %md
# MAGIC Add two more records

# COMMAND ----------

data = [
    (6, "SKU-4001", "Coffee Mug", "Kitchen", 3, 299.00),
    (7, "SKU-5001", "LED Bulb", "Electronics", 4, 149.99)
]


# COMMAND ----------

columns = ["order_id", "sku", "product_name", "product_category", "qty", "unit_price"]

# COMMAND ----------

# Create DataFrame
new_df = spark.createDataFrame(data, columns)
display(new_df)

# COMMAND ----------

volume_path = "/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1"
new_df.write.mode("append").format("delta").save(volume_path)


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * from JSON.`dbfs:/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1/_delta_log/00000000000000000001.json`

# COMMAND ----------

# MAGIC %md
# MAGIC To view history

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

