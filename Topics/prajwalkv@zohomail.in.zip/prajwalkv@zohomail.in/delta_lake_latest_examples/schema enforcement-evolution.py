# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog deltalake_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- current table info & rows
# MAGIC DESCRIBE DETAIL DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1` ORDER BY order_id;

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1` 

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE FORMATTED DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1` 

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW bad_rows AS
# MAGIC SELECT * FROM VALUES
# MAGIC   (10, 'SKU-1009', 'Bad Qty Example', 'Misc', 'two', 99.99)
# MAGIC AS t(order_id, sku, product_name, product_category, qty, unit_price);
# MAGIC
# MAGIC INSERT INTO DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`
# MAGIC SELECT * FROM bad_rows;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW bad_rows AS
# MAGIC SELECT * FROM VALUES
# MAGIC   (10, 'SKU-1009', 'Bad Qty Example', 'Misc', "2" , 99.99)
# MAGIC AS t(order_id, sku, product_name, product_category, qty, unit_price);
# MAGIC
# MAGIC INSERT INTO DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`
# MAGIC SELECT * FROM bad_rows;

# COMMAND ----------

# MAGIC %sql
# MAGIC describe formatted DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW bad_rows AS
# MAGIC SELECT * FROM VALUES
# MAGIC   (11, 'SKU-1009', 'Bad Qty Example', 'Misc', 5.2 , 99.99)
# MAGIC AS t(order_id, sku, product_name, product_category, qty, unit_price);
# MAGIC
# MAGIC INSERT INTO DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`
# MAGIC SELECT * FROM bad_rows;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW extra_col_src AS
# MAGIC SELECT * FROM VALUES
# MAGIC   (12, 'SKU-1010', 'Extra Col Item', 'Misc', 1, 49.00, 5.0)
# MAGIC AS t(order_id, sku, product_name, product_category, qty, unit_price, discount);
# MAGIC
# MAGIC INSERT INTO DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1` SELECT * FROM extra_col_src
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- add a new column 'discount' (DOUBLE) to the target table
# MAGIC ALTER TABLE DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`
# MAGIC ADD COLUMNS (discount DOUBLE);
# MAGIC
# MAGIC
# MAGIC -- Now insert the row with the extra column (works because we added the column)
# MAGIC INSERT INTO DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`
# MAGIC SELECT order_id, sku, product_name, product_category, qty, unit_price, discount
# MAGIC FROM extra_col_src;
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1` ORDER BY order_id;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW incoming_with_newcol AS
# MAGIC SELECT * FROM VALUES
# MAGIC   (13, 'SKU-1011', 'Auto Evolve Item', 'Promo', 2, 199.00, 5, 'PROMO10')
# MAGIC AS t(order_id, sku, product_name, product_category, qty, unit_price, discount,promotion_code);

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE WITH SCHEMA EVOLUTION INTO DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1` AS target
# MAGIC USING incoming_with_newcol AS src
# MAGIC   ON target.order_id = src.order_id
# MAGIC WHEN MATCHED THEN UPDATE SET *
# MAGIC WHEN NOT MATCHED THEN INSERT *;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1` 

# COMMAND ----------

from decimal import Decimal
from pyspark.sql.types import StructType, StructField, LongType, StringType, IntegerType, DecimalType

# Sample new rows that include a new column 'promotion_code'
rows = [
    (5001, 'SKU-5001', 'Promo Item A', 'Promo', 2, 'PROMO10'),
    (5002, 'SKU-5002', 'Promo Item B', 'Promo', 1, 'PROMO20')
]

# Schema includes the new column
schema = StructType([
    StructField("order_id", LongType(), False),
    StructField("sku", StringType(), True),
    StructField("product_name", StringType(), True),
    StructField("product_category", StringType(), True),
    StructField("qty", IntegerType(), True),
    StructField("promo", StringType(), True) 
])

# Create DataFrame
df = spark.createDataFrame(rows, schema=schema)

display(df)


# COMMAND ----------

df.write \
  .format("delta") \
  .mode("append") \
  .option("mergeSchema", "true") \
  .save("/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1")


# COMMAND ----------

from decimal import Decimal
from pyspark.sql.types import StructType, StructField, LongType, StringType, IntegerType, DecimalType

# Sample new rows that include a new column 'promotion_code'
rows = [
    (5003, 'SKU-5001', 'Promo Item A', 'Promo', 2, 'PROMO10'),
    (5004, 'SKU-5002', 'Promo Item B', 'Promo', 1, 'PROMO20')
]

# Schema includes the new column
schema = StructType([
    StructField("order_id", LongType(), False),
    StructField("sku", StringType(), True),
    StructField("product_name", StringType(), True),
    StructField("product_category", StringType(), True),
    StructField("qty", LongType(), True),
    StructField("promo", StringType(), True) 
])

# Create DataFrame
df = spark.createDataFrame(rows, schema=schema)

display(df)


# COMMAND ----------

df.printSchema()

# COMMAND ----------

df.write \
  .format("delta") \
  .mode("append") \
  .option("mergeSchema", "true") \
  .save("/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1")

# COMMAND ----------

# MAGIC %sql
# MAGIC alter table DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1` 
# MAGIC SET tblproperties ('delta.enableTypeWidening' = 'true')

# COMMAND ----------

# MAGIC %sql
# MAGIC show tblproperties DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1` 

# COMMAND ----------

