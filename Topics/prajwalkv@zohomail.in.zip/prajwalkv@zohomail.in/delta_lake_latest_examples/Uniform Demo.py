# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog deltalake_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS orders_managed;
# MAGIC
# MAGIC
# MAGIC CREATE OR REPLACE TABLE orders_managed (
# MAGIC order_id BIGINT,
# MAGIC sku STRING,
# MAGIC product_name STRING,
# MAGIC product_category STRING,
# MAGIC qty INT,
# MAGIC unit_price DECIMAL(10,2)
# MAGIC ) TBLPROPERTIES ( 'delta.columnMapping.mode' = 'name',
# MAGIC 'delta.enableIcebergCompatV2' = 'true',
# MAGIC 'delta.universalFormat.enabledFormats' = 'iceberg'
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO orders_managed VALUES
# MAGIC   (1, 'SKU-1001', 'Wireless Mouse', 'Electronics', 2, 799.00),
# MAGIC   (2, 'SKU-2001', 'Yoga Mat', 'Fitness', 1, 1199.00),
# MAGIC   (3, 'SKU-3001', 'Notebook A5', 'Stationery', 5, 49.50),
# MAGIC   (4, 'SKU-4001', 'Coffee Mug', 'Kitchen', 3, 299.00),
# MAGIC   (5, 'SKU-5001', 'LED Bulb', 'Electronics', 4, 149.99);
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC describe formatted orders_managed

# COMMAND ----------

# MAGIC %sql
# MAGIC show tblproperties orders_managed;