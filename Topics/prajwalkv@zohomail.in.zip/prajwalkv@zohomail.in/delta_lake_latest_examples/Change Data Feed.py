# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog deltalake_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS demo;
# MAGIC
# MAGIC CREATE TABLE demo (
# MAGIC   id INT,
# MAGIC   name STRING,
# MAGIC   amount DOUBLE
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO demo VALUES (1, 'alice', 100.0), (2, 'bob', 200.0), (3, 'carol', 300.0);
# MAGIC SELECT * FROM demo;

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history demo;

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE demo SET TBLPROPERTIES (delta.enableChangeDataFeed = true);

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history demo;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Update
# MAGIC UPDATE demo SET amount = amount * 1.1 WHERE id = 2;
# MAGIC
# MAGIC -- Insert additional
# MAGIC INSERT INTO demo VALUES (4, 'dan', 400.0);
# MAGIC
# MAGIC -- Delete
# MAGIC DELETE FROM demo WHERE id = 1;

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history demo;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM table_changes('demo', 2)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM table_changes('demo', 2, 4)

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM demo WHERE id = 2;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM table_changes('demo', 2)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS demo_deleted_data_batch;
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS demo_deleted_data_batch (
# MAGIC   id INT,
# MAGIC   name STRING,
# MAGIC   amount DOUBLE,
# MAGIC   _commit_type STRING,
# MAGIC   _commit_version LONG,
# MAGIC   _commit_timestamp TIMESTAMP
# MAGIC )
# MAGIC USING delta;

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO demo_deleted_data_batch
# MAGIC SELECT id, name, amount, _change_type, _commit_version, _commit_timestamp 
# MAGIC FROM table_changes('demo', 2)
# MAGIC where _change_type = 'delete';

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from demo_deleted_data_batch;

# COMMAND ----------

from pyspark.sql.functions import col

(spark.readStream.format("delta")
    .option("readChangeFeed", "true")
    .option("startingVersion", 2)  
    .table("demo")
    .filter(col("_change_type") == "delete")  
    .select("id", "name")
    .writeStream
    .outputMode("append")
    .option("checkpointLocation", "/Volumes/deltalake_catalog/default/delta_volume1/checkpoint/") 
    .trigger(availableNow=True) 
    .table("demo_deleted_data_streaming"))

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from demo_deleted_data_streaming;

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM demo WHERE id = 3;

# COMMAND ----------

from pyspark.sql.functions import col

(spark.readStream.format("delta")
    .option("readChangeFeed", "true")
    .option("startingVersion", 2)  
    .table("demo")
    .filter(col("_change_type") == "delete")  
    .select("id", "name")
    .writeStream
    .outputMode("append")
    .option("checkpointLocation", "/Volumes/deltalake_catalog/default/delta_volume1/checkpoint1/") 
    .trigger(processingTime="2 seconds") 
    .table("demo_deleted_data_streaming_auto"))

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from demo_deleted_data_streaming_auto;

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO demo VALUES
# MAGIC   (6, 'Frank', 600.0),
# MAGIC   (7, 'Grace', 700.0),
# MAGIC   (8, 'Heidi', 800.0),
# MAGIC   (9, 'Ivan', 900.0),
# MAGIC   (10, 'Judy', 1000.0);

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM demo WHERE id = 7;

# COMMAND ----------

