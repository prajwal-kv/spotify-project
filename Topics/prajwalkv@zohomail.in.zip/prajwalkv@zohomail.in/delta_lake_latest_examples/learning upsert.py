# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog deltalake_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC create volume if not exists deltalake_catalog.default.deltalake_volume;

# COMMAND ----------

dbutils.fs.mkdirs("/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1")

# COMMAND ----------

from decimal import Decimal
from pyspark.sql.types import StructType, StructField, LongType, StringType, IntegerType, DecimalType

# Sample data with Decimal for unit_price
data = [
    (1, "SKU-1001", "Wireless Mouse", "Electronics", 2, Decimal("799.00")),
    (2, "SKU-2001", "Yoga Mat", "Fitness", 1, Decimal("1199.00")),
    (3, "SKU-3001", "Notebook A5", "Stationery", 5, Decimal("49.50")),
    (4, "SKU-4001", "Coffee Mug", "Kitchen", 3, Decimal("299.00")),
    (5, "SKU-5001", "LED Bulb", "Electronics", 4, Decimal("149.99"))
]

schema = StructType([
    StructField("order_id", LongType(), False),
    StructField("sku", StringType(), True),
    StructField("product_name", StringType(), True),
    StructField("product_category", StringType(), True),
    StructField("qty", IntegerType(), True),
    StructField("unit_price", DecimalType(10,2), True) 
])

df = spark.createDataFrame(data, schema=schema)

display(df)
df.printSchema()

# COMMAND ----------

volume_path = "/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1"
df.write.format("delta").mode("overwrite").save(volume_path)

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW incoming_batch AS
# MAGIC SELECT * FROM VALUES
# MAGIC   (2, 'SKU-2001', 'Yoga Mat - updated', 'Fitness', 2, 1099.00),
# MAGIC   (5, 'SKU-5001', 'LED Bulb - change', 'Electronics', 6, 129.99),
# MAGIC   (6, 'SKU-6001', 'Travel Bottle', 'Accessories', 1, 249.00)
# MAGIC AS t(order_id, sku, product_name, product_category, qty, unit_price);
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1` as target
# MAGIC USING incoming_batch AS src
# MAGIC ON target.order_id = src.order_id
# MAGIC WHEN MATCHED THEN
# MAGIC UPDATE SET 
# MAGIC target.sku = src.sku,
# MAGIC target.product_name = src.product_name,
# MAGIC target.product_category = src.product_category,
# MAGIC target.qty = src.qty,
# MAGIC target.unit_price = src.unit_price
# MAGIC WHEN NOT MATCHED THEN
# MAGIC INSERT (order_id, sku, product_name, product_category, qty, unit_price)
# MAGIC VALUES (src.order_id, src.sku, src.product_name, src.product_category, src.qty, src.unit_price)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW incoming_flag AS
# MAGIC SELECT * FROM VALUES
# MAGIC   (2, 'SKU-2001', 'Yoga Mat - updated', 'Fitness', 2, 1021.00, FALSE),
# MAGIC   (3, 'SKU-3001', 'Notebook A5',      'Stationery', 5, 49.50,   TRUE)
# MAGIC AS t(order_id, sku, product_name, product_category, qty, unit_price, is_deleted);

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1` as target
# MAGIC USING incoming_flag AS src
# MAGIC ON target.order_id = src.order_id
# MAGIC WHEN MATCHED AND src.is_deleted = true THEN
# MAGIC DELETE
# MAGIC WHEN MATCHED THEN
# MAGIC UPDATE SET *
# MAGIC WHEN NOT MATCHED THEN
# MAGIC INSERT *;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`

# COMMAND ----------

# MAGIC %sql
# MAGIC -- snapshot (only these rows should remain after the MERGE)
# MAGIC CREATE OR REPLACE TEMP VIEW incoming_snapshot AS
# MAGIC SELECT * FROM VALUES
# MAGIC   (1, 'SKU-1001', 'Wireless Mouse', 'Electronics', 2, 799.00),
# MAGIC   (2, 'SKU-2001', 'Yoga Mat - snapshot', 'Fitness', 3, 1049.00)
# MAGIC AS t(order_id, sku, product_name, product_category, qty, unit_price);

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1` as target
# MAGIC USING incoming_snapshot AS src
# MAGIC ON target.order_id = src.order_id
# MAGIC WHEN MATCHED THEN UPDATE SET *
# MAGIC WHEN NOT MATCHED THEN INSERT *
# MAGIC WHEN NOT MATCHED BY SOURCE THEN DELETE;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY DELTA.`/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1`

# COMMAND ----------


from delta.tables import DeltaTable

snapshot_rows = [
    (1, 'SKU-1001', 'Wireless Mouse', 'Electronics', 2, 799.00),
    (2, 'SKU-2001', 'Yoga Mat - snapshot', 'Fitness',    3, 1049.00)
]

schema = "order_id LONG, sku STRING, product_name STRING, product_category STRING, qty INT, unit_price DOUBLE"

incoming_snapshot_df = spark.createDataFrame(snapshot_rows, schema=schema)

path = "/Volumes/deltalake_catalog/default/delta_volume1/ordersdata1"
delta_table = DeltaTable.forPath(spark, path)

(delta_table.alias("t")
  .merge(incoming_snapshot_df.alias("s"), "t.order_id = s.order_id")
  .whenMatchedUpdateAll()
  .whenNotMatchedInsertAll()
  .whenNotMatchedBySourceDelete()
  .execute()
)

display(spark.sql(f"SELECT * FROM DELTA.`{path}` ORDER BY order_id"))
display(spark.sql(f"DESCRIBE HISTORY DELTA.`{path}` LIMIT 10"))

# COMMAND ----------

