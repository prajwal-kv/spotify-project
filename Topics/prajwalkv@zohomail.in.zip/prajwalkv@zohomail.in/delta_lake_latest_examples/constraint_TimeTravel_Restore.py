# Databricks notebook source
# MAGIC %sql
# MAGIC alter table databricks_delta_lake_transactions_logs.default.orders_ext_01 alter column order_id SET not NULL

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from orders_ext_01;

# COMMAND ----------

# MAGIC %md
# MAGIC Roll back to earlier versions

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from orders_ext_01 version as of 1;

# COMMAND ----------

# MAGIC %md
# MAGIC Now restore the table

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from orders_ext_01 version as of 2;

# COMMAND ----------

# MAGIC %md
# MAGIC shortcut way

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from orders_ext_01@v3;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from orders_ext_01 timestamp as of '2025-11-02T16:33:37.000+00:00';

# COMMAND ----------

# MAGIC %md
# MAGIC using DF

# COMMAND ----------

df_latest = spark.read.table("orders_ext_01")

# COMMAND ----------

df_latest.show()

# COMMAND ----------

df_v2 = spark.read.option("versionAsOf", 2).table("orders_ext_01")
df_v2.show()

# COMMAND ----------

display(df_v2)

# COMMAND ----------

df_v2 = spark.read.format("delta") \
    .option("timestampAsOf", '2025-11-02T16:33:37.000+00:00') \
    .table("orders_ext_01")

df_v2.show()

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY orders_ext_01;

# COMMAND ----------

# MAGIC %md
# MAGIC To restore the version

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC RESTORE TABLE orders_ext_01 TO VERSION AS OF 1;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from orders_ext_01;

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

