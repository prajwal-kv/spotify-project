# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog deltalake_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS orders_ext_02;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE orders_ext_02 (
# MAGIC order_id BIGINT,
# MAGIC sku STRING,
# MAGIC product_name STRING,
# MAGIC product_category STRING,
# MAGIC qty INT,
# MAGIC unit_price DECIMAL(10,2)
# MAGIC ) 
# MAGIC LOCATION 'abfss://externaldata@newgeneration.dfs.core.windows.net/orders'

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO orders_ext_02 VALUES
# MAGIC   (1, 'SKU-1001', 'Wireless Mouse', 'Electronics', 2, 799.00),
# MAGIC   (2, 'SKU-2001', 'Yoga Mat', 'Fitness', 1, 1199.00),
# MAGIC   (3, 'SKU-3001', 'Notebook A5', 'Stationery', 5, 49.50),
# MAGIC   (4, 'SKU-4001', 'Coffee Mug', 'Kitchen', 3, 299.00),
# MAGIC   (5, 'SKU-5001', 'LED Bulb', 'Electronics', 4, 149.99);

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE FORMATTED orders_ext_02

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE orders_ext_02
# MAGIC ALTER COLUMN order_id SET NOT NULL;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY orders_ext_02;

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE orders_ext_02
# MAGIC ADD CONSTRAINT chk_qty_price CHECK (qty > 0 AND unit_price > 0)

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY orders_ext_02;

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO orders_ext_02 VALUES (6, 'SKU-6001', 'Faulty Item', 'Misc', 0, -10.00);

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create a temp source table (simulate an incoming batch with one bad row)
# MAGIC CREATE OR REPLACE TEMP VIEW incoming AS
# MAGIC SELECT * FROM VALUES
# MAGIC   (2, 'SKU-2001', 'Yoga Mat - new', 'Fitness', 2, 1099.00),   
# MAGIC   (6, 'SKU-6001', 'Invalid Item', 'Misc', 0, -10.00)         
# MAGIC AS t(order_id, sku, product_name, product_category, qty, unit_price);

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO orders_ext_02 AS TARGET
# MAGIC USING incoming AS src
# MAGIC ON TARGET.order_id = src.order_id
# MAGIC WHEN MATCHED THEN UPDATE SET *
# MAGIC WHEN NOT MATCHED THEN INSERT *;

# COMMAND ----------

# MAGIC %sql
# MAGIC select sum(qty) as total_qty from orders_ext_02;
# MAGIC update orders_ext_02 set qty = qty + 10 where order_id = 1

# COMMAND ----------

