# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog deltalake_catalog;

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS orders_managed;
# MAGIC
# MAGIC CREATE OR REPLACE TABLE orders_managed (
# MAGIC   order_id BIGINT,
# MAGIC   sku STRING,
# MAGIC   product_name STRING,
# MAGIC   product_category STRING,
# MAGIC   qty INT,
# MAGIC   unit_price DECIMAL(10,2)
# MAGIC )
# MAGIC USING DELTA
# MAGIC TBLPROPERTIES (
# MAGIC   delta.autoOptimize.optimizeWrite = false,
# MAGIC   delta.autoOptimize.autoCompact = false
# MAGIC )
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Under property column,we can see the autocompact and optimizewrite is in false state

# COMMAND ----------

# MAGIC %sql
# MAGIC describe detail orders_managed;

# COMMAND ----------

from pyspark.sql import Row
from pyspark.sql.types import DecimalType
from pyspark.sql.functions import col
import time


N = 100

for i in range(N):
    row = Row(order_id=int(i+1),
              sku=f"SKU-{(i%10)+1}",
              product_name=f"Product-{(i%50)+1}",
              product_category=f"Category-{(i%5)+1}",
              qty=(i % 10) + 1,
              unit_price=round(10.0 + (i%7)*1.5, 2))
    
    df = spark.createDataFrame([row])

    df = df.withColumn("qty", col("qty").cast("int")).withColumn("unit_price", col("unit_price").cast(DecimalType(10,2)))
    
    df.write.format("delta").mode("append").saveAsTable("orders_managed")
    # optional tiny sleep to mimic real small-batch writes
    # time.sleep(0.02)

print(f"Inserted {N} tiny writes.")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from orders_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from orders_managed where order_id = 56;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from orders_managed;

# COMMAND ----------

query = "select AVG(unit_price) as avg_price from orders_managed"
res = spark.sql(query).collect()
print(res)

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY orders_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE FORMATTED orders_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE orders_managed;

# COMMAND ----------

query = "select AVG(unit_price) as avg_price from orders_managed"
res = spark.sql(query).collect()
print(res)

# COMMAND ----------

