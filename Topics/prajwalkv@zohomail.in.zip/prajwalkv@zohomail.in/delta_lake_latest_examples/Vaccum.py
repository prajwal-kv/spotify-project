# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog deltalake_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC DROP TABLE orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS databricks_delta_lake_transactions_logs.default.orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS deltalake_catalog.default.orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog deltalake_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE deltalake_catalog.default.orders_ext_02(
# MAGIC order_id BIGINT,
# MAGIC sku STRING,
# MAGIC product_name STRING,
# MAGIC product_category STRING,
# MAGIC qty INT,
# MAGIC unit_price DECIMAL(10,2)
# MAGIC )
# MAGIC TBLPROPERTIES (
# MAGIC   delta.autoOptimize.optimizeWrite = false,
# MAGIC   delta.autoOptimize.autoCompact = false
# MAGIC )
# MAGIC LOCATION 'abfss://externaldata@newgeneration.dfs.core.windows.net/orders'
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE deltalake_catalog.default.orders_ext_01(
# MAGIC   order_id BIGINT,
# MAGIC   sku STRING,
# MAGIC   product_name STRING,
# MAGIC   product_category STRING,
# MAGIC   qty INT,
# MAGIC   unit_price DECIMAL(10,2)
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION 'abfss://externaldata@newgeneration.dfs.core.windows.net/orders';

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE deltalake_catalog.default.orders_ext_01 
# MAGIC SET TBLPROPERTIES (
# MAGIC   'delta.autoOptimize.optimizeWrite' = 'false',
# MAGIC   'delta.autoOptimize.autoCompact' = 'false'
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TBLPROPERTIES deltalake_catalog.default.orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO deltalake_catalog.default.orders_ext_01
# MAGIC (order_id, sku, product_name, product_category, qty, unit_price)
# MAGIC VALUES
# MAGIC (1, 'SKU-1001', 'Wireless Mouse', 'Electronics', 2, 799.00),
# MAGIC (2, 'SKU-2001', 'Yoga Mat', 'Fitness', 1, 1199.00),
# MAGIC (3, 'SKU-3001', 'Notebook A5', 'Stationery', 5, 49.50),
# MAGIC (4, 'SKU-4001', 'Coffee Mug', 'Kitchen', 3, 299.00),
# MAGIC (5, 'SKU-5001', 'LED Bulb', 'Electronics', 4, 149.99);

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE deltalake_catalog.default.orders_ext_01
# MAGIC SET unit_price = unit_price * 1.15
# MAGIC WHERE product_category = 'Electronics';
# MAGIC     
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY deltalake_catalog.default.orders_ext_01

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * from JSON.`abfss://externaldata@newgeneration.dfs.core.windows.net/orders/_delta_log/00000000000000000002.json`

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT OVERWRITE deltalake_catalog.default.orders_ext_01
# MAGIC (order_id, sku, product_name, product_category, qty, unit_price)
# MAGIC VALUES (8, 'SKU-1008', 'Wireless Mouse', 'Electronics', 8, 788.00);

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY deltalake_catalog.default.orders_ext_01;

# COMMAND ----------

# MAGIC %md
# MAGIC used to identify the latest referenced file and @v1 ->specific to verion files

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT _metadata.file_path FROM deltalake_catalog.default.orders_ext_01;

# COMMAND ----------

# MAGIC %md
# MAGIC which files are required for v2

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT _metadata.file_path FROM deltalake_catalog.default.orders_ext_01@v2;

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM deltalake_catalog.default.orders_ext_01;

# COMMAND ----------

# MAGIC %md
# MAGIC use dry run to check which files will be deleted after entering the above command.
# MAGIC
# MAGIC
# MAGIC Zero rows returned as none of the files are 7 days older.

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM deltalake_catalog.default.orders_ext_01 DRY RUN;

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM deltalake_catalog.default.orders_ext_01 retain 0 hours DRY RUN;

# COMMAND ----------

# MAGIC %md
# MAGIC Now it won't throw error.Now we can delete

# COMMAND ----------

spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled","false")

# COMMAND ----------

# MAGIC %md
# MAGIC These files will be  deleted as these files are refered in the lastest versions

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM deltalake_catalog.default.orders_ext_01 retain 0 hours DRY RUN;

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM deltalake_catalog.default.orders_ext_01 retain 0 hours

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY deltalake_catalog.default.orders_ext_01

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from deltalake_catalog.default.orders_ext_01;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from deltalake_catalog.default.orders_ext_01@v2;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from deltalake_catalog.default.orders_ext_01@v2;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT _metadata.file_path FROM deltalake_catalog.default.orders_ext_01@v2;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from deltalake_catalog.default.orders_ext_01@v2;

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

