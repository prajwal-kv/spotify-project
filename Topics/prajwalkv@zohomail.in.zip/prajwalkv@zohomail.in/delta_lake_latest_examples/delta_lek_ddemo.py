# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE orders_managed (
# MAGIC order_id BIGINT,
# MAGIC sku STRING,
# MAGIC product_name STRING,
# MAGIC product_category STRING,
# MAGIC qty INT,
# MAGIC unit_price DECIMAL(10,2)
# MAGIC ) USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO orders_managed VALUES
# MAGIC (1, 'A101', 'iPhone Charger', 'Electronics', 2, 19.99),
# MAGIC (2, 'A102', 'Bluetooth Headphones', 'Electronics', 1, 49.50),
# MAGIC (3, 'A103', 'HDMI Cable', 'Electronics', 3, 5.99);

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE DETAIL orders_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE FORMATTED orders_managed;

# COMMAND ----------

# MAGIC %md
# MAGIC How to demonstarte the delta examples.for that we have to create our own catalog

# COMMAND ----------

# MAGIC %sql
# MAGIC create catalog deltalake_catalog
# MAGIC managed location 'abfss://unitycatalog@newgeneration.dfs.core.windows.net/catalog'

# COMMAND ----------

# MAGIC %sql
# MAGIC USE CATALOG deltalake_catalog

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT current_metastore();

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT current_catalog();

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE deltalake_catalog.default.orders_managed (
# MAGIC order_id BIGINT,
# MAGIC sku STRING,
# MAGIC product_name STRING,
# MAGIC product_category STRING,
# MAGIC qty INT,
# MAGIC unit_price DECIMAL(10,2)
# MAGIC ) USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO deltalake_catalog.default.orders_managed  VALUES
# MAGIC (1, 'A101', 'iPhone Charger', 'Electronics', 2, 19.99),
# MAGIC (2, 'A102', 'Bluetooth Headphones', 'Electronics', 1, 49.50),
# MAGIC (3, 'A103', 'HDMI Cable', 'Electronics', 3, 5.99);

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE FORMATTED deltalake_catalog.default.orders_managed ;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE DETAIL deltalake_catalog.default.orders_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS deltalake_catalog.default.orders_managed;

# COMMAND ----------

display(dbutils.fs.ls("abfss://unitycatalog@newgeneration.dfs.core.windows.net/catalog"))

# COMMAND ----------

# MAGIC %md
# MAGIC Eventhough we created our own catlog and with storage location governed in catalog .we can't view the physical content using dbutils(only viewing inside parquet+sanppy file and delta log JSON is possible).

# COMMAND ----------

dbutils.fs.ls("abfss://unitycatalog@newgeneration.dfs.core.windows.net/catalog/__unitystorage/catalogs/9a59face-dd5e-4639-b31e-a34b08828a6e/tables/8b10cae3-48f0-4d22-812b-d45602447a0b")

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

