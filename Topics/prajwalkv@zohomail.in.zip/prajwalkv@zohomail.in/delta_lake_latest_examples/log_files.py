# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE deltalake_catalog.default.orders_ext_02(
# MAGIC order_id BIGINT,
# MAGIC sku STRING,
# MAGIC product_name STRING,
# MAGIC product_category STRING,
# MAGIC qty INT,
# MAGIC unit_price DECIMAL(10,2)
# MAGIC )
# MAGIC LOCATION 'abfss://externaldata@newgeneration.dfs.core.windows.net/orders'
# MAGIC

# COMMAND ----------

for i in range(100):  # 100 small commits – adjust smaller/larger as needed
    order_id = 1000 + i
    sku = f"SKU-BURST-{i}"
    name = f"Burst-{i}"
    category = "Demo"
    qty = 1
    price = float(i % 10 + 1) * 1.0
    sql = f"""
    INSERT INTO deltalake_catalog.default.orders_ext_02 VALUES ({order_id}, '{sku}', '{name}', '{category}', {qty}, {price});
    """
    spark.sql(sql)

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from deltalake_catalog.default.orders_ext_02;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY deltalake_catalog.default.orders_ext_02;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM JSON.`abfss://externaldata@newgeneration.dfs.core.windows.net/orders/_delta_log/00000000000000000001.00000000000000000006.compacted.json`
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * from PARQUET.`abfss://externaldata@newgeneration.dfs.core.windows.net/orders/_delta_log/00000000000000000036.checkpoint.parquet`

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

