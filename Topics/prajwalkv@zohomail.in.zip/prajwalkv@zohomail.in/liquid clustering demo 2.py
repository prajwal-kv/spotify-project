# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog deltalake_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS demo_taxi_200files;
# MAGIC CREATE TABLE demo_taxi_200files (
# MAGIC   vendor_id STRING,
# MAGIC   pickup_datetime TIMESTAMP,
# MAGIC   dropoff_datetime TIMESTAMP,
# MAGIC   passenger_count INT,
# MAGIC   trip_distance DOUBLE,
# MAGIC   pickup_longitude DOUBLE,
# MAGIC   pickup_latitude DOUBLE,
# MAGIC   rate_code_id INT,
# MAGIC   store_and_fwd_flag STRING,
# MAGIC   dropoff_longitude DOUBLE,
# MAGIC   dropoff_latitude DOUBLE,
# MAGIC   payment_type STRING,
# MAGIC   fare_amount DOUBLE,
# MAGIC   extra DOUBLE,
# MAGIC   mta_tax DOUBLE,
# MAGIC   tip_amount DOUBLE,
# MAGIC   tolls_amount DOUBLE,
# MAGIC   total_amount DOUBLE
# MAGIC )
# MAGIC USING DELTA
# MAGIC PARTITIONED BY (vendor_id)
# MAGIC TBLPROPERTIES (
# MAGIC   delta.autoOptimize.optimizeWrite = false,
# MAGIC   delta.autoOptimize.autoCompact = false
# MAGIC );
# MAGIC

# COMMAND ----------

# Find the table location from DESCRIBE DETAIL first:
table_location = "dbfs:/databricks-datasets/nyctaxi/tables/nyctaxi_yellow"

# List data files (ignore _delta_log)
all_files = [f.path for f in dbutils.fs.ls(table_location) if f.path.endswith(".parquet")]

# Pick first 10 files
files10 = all_files[:10]
print("Using these 10 files:", files10)

# Read them as Parquet
df_10 = spark.read.parquet(*files10)

# Repartition into 200 files and write into your demo Delta table
df_10.repartition(200).write.format("delta").mode("overwrite").saveAsTable("demo_taxi_200files")

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from demo_taxi_200files where trip_distance > 100

# COMMAND ----------

# MAGIC %sql
# MAGIC optimize demo_taxi_200files zorder by (trip_distance)

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from demo_taxi_200files where trip_distance > 100

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(trip_distance), max(trip_distance), _metadata.file_name
# MAGIC from demo_taxi_200files
# MAGIC group by _metadata.file_name
# MAGIC order by min(trip_distance)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS demo_taxi_200files;
# MAGIC CREATE TABLE demo_taxi_200files (
# MAGIC   vendor_id STRING,
# MAGIC   pickup_datetime TIMESTAMP,
# MAGIC   dropoff_datetime TIMESTAMP,
# MAGIC   passenger_count INT,
# MAGIC   trip_distance DOUBLE,
# MAGIC   pickup_longitude DOUBLE,
# MAGIC   pickup_latitude DOUBLE,
# MAGIC   rate_code_id INT,
# MAGIC   store_and_fwd_flag STRING,
# MAGIC   dropoff_longitude DOUBLE,
# MAGIC   dropoff_latitude DOUBLE,
# MAGIC   payment_type STRING,
# MAGIC   fare_amount DOUBLE,
# MAGIC   extra DOUBLE,
# MAGIC   mta_tax DOUBLE,
# MAGIC   tip_amount DOUBLE,
# MAGIC   tolls_amount DOUBLE,
# MAGIC   total_amount DOUBLE
# MAGIC )
# MAGIC USING DELTA
# MAGIC CLUSTER BY (vendor_id, trip_distance)
# MAGIC TBLPROPERTIES (
# MAGIC   delta.autoOptimize.optimizeWrite = false,
# MAGIC   delta.autoOptimize.autoCompact = false
# MAGIC );
# MAGIC

# COMMAND ----------

# Find the table location from DESCRIBE DETAIL first:
table_location = "dbfs:/databricks-datasets/nyctaxi/tables/nyctaxi_yellow"

# List data files (ignore _delta_log)
all_files = [f.path for f in dbutils.fs.ls(table_location) if f.path.endswith(".parquet")]

# Pick first 10 files
files10 = all_files[:10]
print("Using these 10 files:", files10)

# Read them as Parquet
df_10 = spark.read.parquet(*files10)

# Repartition into 200 files and write into your demo Delta table
df_10.repartition(200).write.format("delta").mode("overwrite").saveAsTable("demo_taxi_200files")

# COMMAND ----------

# MAGIC %sql
# MAGIC describe detail demo_taxi_200files;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from demo_taxi_200files where trip_distance > 100

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(trip_distance), max(trip_distance), _metadata.file_name
# MAGIC from demo_taxi_200files
# MAGIC group by _metadata.file_name
# MAGIC order by min(trip_distance)

# COMMAND ----------

