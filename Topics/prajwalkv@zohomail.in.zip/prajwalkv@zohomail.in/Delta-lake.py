# Databricks notebook source
# MAGIC %md
# MAGIC mount the storage account

# COMMAND ----------

dbutils.fs.mount(
source = 'wasbs://input-datasets@databrick1storageaccount.blob.core.windows.net',
mount_point = '/mnt/retaildb',
extra_configs=
{'fs.azure.account.key.databrick1storageaccount.blob.core.windows.net':'5GwZWbABqW8c8P4XhRlVlJkB1zZAh1/9g6ImrVrMjia3px0rc8+TtT0hKwZLPtdE0Uwqf9I6Qvtc+AStSBDlGA=='}
)


# COMMAND ----------

# MAGIC %md
# MAGIC Better approach

# COMMAND ----------

storage_account_name = "databrick1storageaccount"
container_name = "input-datasets"
storage_account_key = "5GwZWbABqW8c8P4XhRlVlJkB1zZAh1/9g6ImrVrMjia3px0rc8+TtT0hKwZLPtdE0Uwqf9I6Qvtc+AStSBDlGA=="

# Configure access (one-time setup per notebook/session)
spark.conf.set(
    f"fs.azure.account.key.{storage_account_name}.blob.core.windows.net",
    storage_account_key
)

# COMMAND ----------

display(dbutils.fs.ls(f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/"))

# COMMAND ----------

df1 = spark.read.csv('wasbs://input-datasets@databrick1storageaccount.blob.core.windows.net/orders1.csv',header = True)
display(df1)

# COMMAND ----------

# MAGIC %md
# MAGIC Write the df in parquet format to the storage account

# COMMAND ----------


df1.write.mode("overwrite").partitionBy("order_status").format("parquet").save("/mnt/retaildb/parquet/orders.parquet")

# COMMAND ----------

df1.write.mode("overwrite").partitionBy("order_status").format("parquet").save(
    f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/parquet/orders"
)

# COMMAND ----------

# MAGIC %md
# MAGIC Now save it in delta format

# COMMAND ----------

df1.write.mode("overwrite").partitionBy("order_status").format("delta").save(
    f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/delta/orders"
)

# COMMAND ----------

# MAGIC %sql
# MAGIC create database if not exists retaildb

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE retaildb.ordersparquet
# MAGIC USING parquet
# MAGIC LOCATION  "wasbs://input-datasets@databrick1storageaccount.blob.core.windows.net/parquet/orders"

# COMMAND ----------

# Set credentials
spark.conf.set(
  "fs.azure.account.key.databrick1storageaccount.blob.core.windows.net",
  "your-storage-account-key"
)

# Read and create managed table
df = spark.read.parquet(f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/delta/orders")


# COMMAND ----------

df.write.format("parquet").mode("overwrite").saveAsTable("retaildb.ordersparquet")

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

