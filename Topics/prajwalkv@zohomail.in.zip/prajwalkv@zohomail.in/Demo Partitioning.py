# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog deltalake_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS orders_managed;
# MAGIC
# MAGIC CREATE OR REPLACE TABLE orders_managed (
# MAGIC   order_id BIGINT,
# MAGIC   sku STRING,
# MAGIC   product_name STRING,
# MAGIC   product_category STRING,
# MAGIC   qty INT,
# MAGIC   unit_price DECIMAL(10,2),
# MAGIC   country STRING
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO orders_managed VALUES
# MAGIC (1, 'SKU-001', 'Widget A', 'Widgets', 2, 199.99, 'IN'),
# MAGIC (2, 'SKU-002', 'Widget B', 'Widgets', 1, 149.99, 'IN'),
# MAGIC (3, 'SKU-003', 'Widget C', 'Widgets', 3, 99.50,  'IN'),
# MAGIC (4, 'SKU-004', 'Widget D', 'Widgets', 5, 75.00,  'IN'),
# MAGIC (5, 'SKU-005', 'Widget E', 'Widgets', 4, 120.00, 'IN'),
# MAGIC (6, 'SKU-006', 'Gadget A', 'Gadgets', 1, 220.00, 'IN'),
# MAGIC (7, 'SKU-007', 'Gadget B', 'Gadgets', 2, 199.00, 'IN'),
# MAGIC (8, 'SKU-008', 'Gadget C', 'Gadgets', 6, 85.00,  'IN'),
# MAGIC (9, 'SKU-009', 'Gadget D', 'Gadgets', 2, 65.50,  'IN'),
# MAGIC (10, 'SKU-010', 'Accessory A', 'Accessories', 10, 5.50, 'IN'),
# MAGIC
# MAGIC (11, 'SKU-011', 'Widget F', 'Widgets', 2, 155.00, 'US'),
# MAGIC (12, 'SKU-012', 'Widget G', 'Widgets', 1, 135.00, 'US'),
# MAGIC (13, 'SKU-013', 'Widget H', 'Widgets', 7, 89.99,  'US'),
# MAGIC (14, 'SKU-014', 'Widget I', 'Widgets', 4, 180.00, 'US'),
# MAGIC (15, 'SKU-015', 'Widget J', 'Widgets', 3, 160.00, 'US'),
# MAGIC (16, 'SKU-016', 'Gadget E', 'Gadgets', 2, 99.00, 'US'),
# MAGIC (17, 'SKU-017', 'Gadget F', 'Gadgets', 5, 115.00, 'US'),
# MAGIC (18, 'SKU-018', 'Accessory B', 'Accessories', 12, 8.00, 'US'),
# MAGIC (19, 'SKU-019', 'Accessory C', 'Accessories', 6, 6.50, 'US'),
# MAGIC (20, 'SKU-020', 'Accessory D', 'Accessories', 8, 12.00, 'US'),
# MAGIC
# MAGIC (21, 'SKU-021', 'Widget K', 'Widgets', 2, 175.00, 'US'),
# MAGIC (22, 'SKU-022', 'Gadget G', 'Gadgets', 3, 210.00, 'US'),
# MAGIC (23, 'SKU-023', 'Accessory E', 'Accessories', 9, 14.00, 'US'),
# MAGIC (24, 'SKU-024', 'Accessory F', 'Accessories', 11, 9.99, 'US'),
# MAGIC (25, 'SKU-025', 'Widget L', 'Widgets', 4, 140.00, 'US'),
# MAGIC
# MAGIC (26, 'SKU-026', 'Widget M', 'Widgets', 2, 120.00, 'UK'),
# MAGIC (27, 'SKU-027', 'Gadget H', 'Gadgets', 1, 99.00, 'UK'),
# MAGIC (28, 'SKU-028', 'Accessory G', 'Accessories', 5, 6.00, 'UK'),
# MAGIC
# MAGIC (29, 'SKU-029', 'Widget N', 'Widgets', 1, 135.00, 'AU'),
# MAGIC (30, 'SKU-030', 'Gadget I', 'Gadgets', 3, 145.00, 'AU'),
# MAGIC (31, 'SKU-031', 'Accessory H', 'Accessories', 2, 12.00, 'AU'),
# MAGIC
# MAGIC (32, 'SKU-032', 'Widget O', 'Widgets', 1, 175.00, 'CA'),
# MAGIC (33, 'SKU-033', 'Gadget J', 'Gadgets', 2, 155.00, 'CA'),
# MAGIC (34, 'SKU-034', 'Accessory I', 'Accessories', 4, 11.00, 'CA'),
# MAGIC
# MAGIC (35, 'SKU-035', 'Widget P', 'Widgets', 1, 185.00, 'DE'),
# MAGIC (36, 'SKU-036', 'Gadget K', 'Gadgets', 2, 165.00, 'DE'),
# MAGIC
# MAGIC (37, 'SKU-037', 'Accessory J', 'Accessories', 6, 7.50, 'IN'),
# MAGIC (38, 'SKU-038', 'Accessory K', 'Accessories', 3, 6.80, 'IN'),
# MAGIC (39, 'SKU-039', 'Accessory L', 'Accessories', 4, 15.00, 'IN'),
# MAGIC (40, 'SKU-040', 'Widget Q', 'Widgets', 2, 190.00, 'IN'),
# MAGIC (41, 'SKU-041', 'Widget R', 'Widgets', 3, 110.00, 'IN'),
# MAGIC (42, 'SKU-042', 'Gadget L', 'Gadgets', 5, 130.00, 'IN'),
# MAGIC (43, 'SKU-043', 'Gadget M', 'Gadgets', 1, 200.00, 'IN'),
# MAGIC (44, 'SKU-044', 'Accessory M', 'Accessories', 9, 10.00, 'IN'),
# MAGIC (45, 'SKU-045', 'Accessory N', 'Accessories', 6, 8.00, 'IN'),
# MAGIC
# MAGIC (46, 'SKU-046', 'Widget S', 'Widgets', 1, 175.00, 'US'),
# MAGIC (47, 'SKU-047', 'Gadget N', 'Gadgets', 3, 145.00, 'US'),
# MAGIC (48, 'SKU-048', 'Accessory O', 'Accessories', 2, 12.00, 'US'),
# MAGIC (49, 'SKU-049', 'Accessory P', 'Accessories', 4, 11.00, 'US'),
# MAGIC (50, 'SKU-050', 'Widget T', 'Widgets', 2, 160.00, 'US');
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE orders_managed_partitioned;
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS orders_managed_partitioned(
# MAGIC   order_id BIGINT,
# MAGIC   sku STRING,
# MAGIC   product_name STRING,
# MAGIC   product_category STRING,
# MAGIC   qty INT,
# MAGIC   unit_price DECIMAL(10,2),
# MAGIC   country STRING
# MAGIC )
# MAGIC USING DELTA
# MAGIC PARTITIONED BY (country);

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into orders_managed_partitioned
# MAGIC select * from orders_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO orders_managed_partitioned VALUES
# MAGIC (51, 'SKU-051', 'Widget U', 'Widgets', 2, 145.00, 'IN'),
# MAGIC (52, 'SKU-052', 'Widget V', 'Widgets', 1, 180.00, 'IN'),
# MAGIC (53, 'SKU-053', 'Widget W', 'Widgets', 3, 135.00, 'IN'),
# MAGIC (54, 'SKU-054', 'Gadget O', 'Gadgets', 4, 210.00, 'IN'),
# MAGIC (55, 'SKU-055', 'Gadget P', 'Gadgets', 2, 175.00, 'IN'),
# MAGIC (56, 'SKU-056', 'Accessory Q', 'Accessories', 6, 10.50, 'IN'),
# MAGIC (57, 'SKU-057', 'Accessory R', 'Accessories', 3, 8.25, 'IN'),
# MAGIC (58, 'SKU-058', 'Accessory S', 'Accessories', 5, 11.00, 'IN'),
# MAGIC (59, 'SKU-059', 'Widget X', 'Widgets', 4, 160.00, 'IN'),
# MAGIC (60, 'SKU-060', 'Widget Y', 'Widgets', 2, 190.00, 'IN'),
# MAGIC
# MAGIC (61, 'SKU-061', 'Gadget Q', 'Gadgets', 1, 125.00, 'US'),
# MAGIC (62, 'SKU-062', 'Gadget R', 'Gadgets', 2, 135.00, 'US'),
# MAGIC (63, 'SKU-063', 'Gadget S', 'Gadgets', 3, 145.00, 'US'),
# MAGIC (64, 'SKU-064', 'Widget Z', 'Widgets', 5, 165.00, 'US'),
# MAGIC (65, 'SKU-065', 'Widget AA', 'Widgets', 4, 175.00, 'US'),
# MAGIC (66, 'SKU-066', 'Accessory T', 'Accessories', 7, 15.00, 'US'),
# MAGIC (67, 'SKU-067', 'Accessory U', 'Accessories', 6, 10.00, 'US'),
# MAGIC (68, 'SKU-068', 'Accessory V', 'Accessories', 8, 9.50,  'US'),
# MAGIC (69, 'SKU-069', 'Accessory W', 'Accessories', 9, 13.00, 'US'),
# MAGIC (70, 'SKU-070', 'Accessory X', 'Accessories', 11, 7.25, 'US'),
# MAGIC
# MAGIC (71, 'SKU-071', 'Widget AB', 'Widgets', 2, 140.00, 'US'),
# MAGIC (72, 'SKU-072', 'Gadget T', 'Gadgets', 3, 200.00, 'US'),
# MAGIC (73, 'SKU-073', 'Accessory Y', 'Accessories', 4, 12.00, 'US'),
# MAGIC (74, 'SKU-074', 'Accessory Z', 'Accessories', 5, 13.50, 'US'),
# MAGIC (75, 'SKU-075', 'Widget AC', 'Widgets', 1, 155.00, 'US'),
# MAGIC
# MAGIC (76, 'SKU-076', 'Widget AD', 'Widgets', 1, 175.00, 'UK'),
# MAGIC (77, 'SKU-077', 'Gadget U', 'Gadgets', 2, 165.00, 'UK'),
# MAGIC (78, 'SKU-078', 'Accessory AA', 'Accessories', 3, 8.50, 'UK'),
# MAGIC
# MAGIC (79, 'SKU-079', 'Widget AE', 'Widgets', 1, 180.00, 'AU'),
# MAGIC (80, 'SKU-080', 'Gadget V', 'Gadgets', 2, 140.00, 'AU'),
# MAGIC (81, 'SKU-081', 'Accessory AB', 'Accessories', 4, 6.75, 'AU'),
# MAGIC
# MAGIC (82, 'SKU-082', 'Widget AF', 'Widgets', 1, 195.00, 'CA'),
# MAGIC (83, 'SKU-083', 'Gadget W', 'Gadgets', 2, 150.00, 'CA'),
# MAGIC (84, 'SKU-084', 'Accessory AC', 'Accessories', 3, 10.00, 'CA'),
# MAGIC
# MAGIC (85, 'SKU-085', 'Widget AG', 'Widgets', 1, 205.00, 'DE'),
# MAGIC (86, 'SKU-086', 'Gadget X', 'Gadgets', 2, 160.00, 'DE'),
# MAGIC
# MAGIC (87, 'SKU-087', 'Accessory AD', 'Accessories', 6, 9.50, 'IN'),
# MAGIC (88, 'SKU-088', 'Accessory AE', 'Accessories', 3, 7.25, 'IN'),
# MAGIC (89, 'SKU-089', 'Accessory AF', 'Accessories', 5, 12.25, 'IN'),
# MAGIC (90, 'SKU-090', 'Widget AH', 'Widgets', 2, 175.00, 'IN'),
# MAGIC (91, 'SKU-091', 'Widget AI', 'Widgets', 4, 185.00, 'IN'),
# MAGIC (92, 'SKU-092', 'Gadget Y', 'Gadgets', 1, 220.00, 'IN'),
# MAGIC (93, 'SKU-093', 'Gadget Z', 'Gadgets', 2, 200.00, 'IN'),
# MAGIC (94, 'SKU-094', 'Accessory AG', 'Accessories', 7, 14.00, 'IN'),
# MAGIC (95, 'SKU-095', 'Accessory AH', 'Accessories', 8, 15.00, 'IN'),
# MAGIC
# MAGIC (96, 'SKU-096', 'Widget AJ', 'Widgets', 1, 165.00, 'US'),
# MAGIC (97, 'SKU-097', 'Gadget AA', 'Gadgets', 3, 145.00, 'US'),
# MAGIC (98, 'SKU-098', 'Accessory AI', 'Accessories', 2, 11.00, 'US'),
# MAGIC (99, 'SKU-099', 'Accessory AJ', 'Accessories', 4, 13.00, 'US'),
# MAGIC (100, 'SKU-100', 'Widget AK', 'Widgets', 2, 170.00, 'US');
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO orders_managed_partitioned VALUES
# MAGIC (101, 'SKU-101', 'Widget AL', 'Widgets', 2, 155.00, 'IN'),
# MAGIC (102, 'SKU-102', 'Widget AM', 'Widgets', 1, 165.00, 'IN'),
# MAGIC (103, 'SKU-103', 'Widget AN', 'Widgets', 3, 175.00, 'IN'),
# MAGIC (104, 'SKU-104', 'Gadget AB', 'Gadgets', 4, 180.00, 'IN'),
# MAGIC (105, 'SKU-105', 'Gadget AC', 'Gadgets', 2, 195.00, 'IN'),
# MAGIC (106, 'SKU-106', 'Accessory AK', 'Accessories', 5, 10.00, 'IN'),
# MAGIC (107, 'SKU-107', 'Accessory AL', 'Accessories', 3, 11.00, 'IN'),
# MAGIC (108, 'SKU-108', 'Accessory AM', 'Accessories', 4, 12.50, 'IN'),
# MAGIC (109, 'SKU-109', 'Widget AO', 'Widgets', 1, 185.00, 'IN'),
# MAGIC (110, 'SKU-110', 'Widget AP', 'Widgets', 2, 195.00, 'IN'),
# MAGIC
# MAGIC (111, 'SKU-111', 'Gadget AD', 'Gadgets', 1, 125.00, 'US'),
# MAGIC (112, 'SKU-112', 'Gadget AE', 'Gadgets', 2, 140.00, 'US'),
# MAGIC (113, 'SKU-113', 'Gadget AF', 'Gadgets', 3, 155.00, 'US'),
# MAGIC (114, 'SKU-114', 'Widget AQ', 'Widgets', 5, 170.00, 'US'),
# MAGIC (115, 'SKU-115', 'Widget AR', 'Widgets', 4, 165.00, 'US'),
# MAGIC (116, 'SKU-116', 'Accessory AN', 'Accessories', 7, 16.00, 'US'),
# MAGIC (117, 'SKU-117', 'Accessory AO', 'Accessories', 6, 9.50, 'US'),
# MAGIC (118, 'SKU-118', 'Accessory AP', 'Accessories', 8, 10.25, 'US'),
# MAGIC (119, 'SKU-119', 'Accessory AQ', 'Accessories', 9, 14.25, 'US'),
# MAGIC (120, 'SKU-120', 'Accessory AR', 'Accessories', 10, 8.00, 'US'),
# MAGIC
# MAGIC (121, 'SKU-121', 'Widget AS', 'Widgets', 2, 150.00, 'US'),
# MAGIC (122, 'SKU-122', 'Gadget AG', 'Gadgets', 3, 200.00, 'US'),
# MAGIC (123, 'SKU-123', 'Accessory AS', 'Accessories', 4, 12.75, 'US'),
# MAGIC (124, 'SKU-124', 'Accessory AT', 'Accessories', 5, 13.25, 'US'),
# MAGIC (125, 'SKU-125', 'Widget AT', 'Widgets', 1, 155.00, 'US'),
# MAGIC
# MAGIC (126, 'SKU-126', 'Widget AU', 'Widgets', 1, 175.00, 'UK'),
# MAGIC (127, 'SKU-127', 'Gadget AH', 'Gadgets', 2, 165.00, 'UK'),
# MAGIC (128, 'SKU-128', 'Accessory AU', 'Accessories', 3, 9.25, 'UK'),
# MAGIC
# MAGIC (129, 'SKU-129', 'Widget AV', 'Widgets', 1, 185.00, 'AU'),
# MAGIC (130, 'SKU-130', 'Gadget AI', 'Gadgets', 2, 145.00, 'AU'),
# MAGIC (131, 'SKU-131', 'Accessory AV', 'Accessories', 4, 6.25, 'AU'),
# MAGIC
# MAGIC (132, 'SKU-132', 'Widget AW', 'Widgets', 1, 195.00, 'CA'),
# MAGIC (133, 'SKU-133', 'Gadget AJ', 'Gadgets', 2, 150.00, 'CA'),
# MAGIC (134, 'SKU-134', 'Accessory AW', 'Accessories', 3, 10.50, 'CA'),
# MAGIC
# MAGIC (135, 'SKU-135', 'Widget AX', 'Widgets', 1, 205.00, 'DE'),
# MAGIC (136, 'SKU-136', 'Gadget AK', 'Gadgets', 2, 160.00, 'DE'),
# MAGIC
# MAGIC (137, 'SKU-137', 'Accessory AX', 'Accessories', 6, 9.25, 'IN'),
# MAGIC (138, 'SKU-138', 'Accessory AY', 'Accessories', 3, 7.75, 'IN'),
# MAGIC (139, 'SKU-139', 'Accessory AZ', 'Accessories', 5, 12.75, 'IN'),
# MAGIC (140, 'SKU-140', 'Widget AY', 'Widgets', 2, 175.00, 'IN'),
# MAGIC (141, 'SKU-141', 'Widget AZ', 'Widgets', 4, 185.00, 'IN'),
# MAGIC (142, 'SKU-142', 'Gadget AL', 'Gadgets', 1, 220.00, 'IN'),
# MAGIC (143, 'SKU-143', 'Gadget AM', 'Gadgets', 2, 200.00, 'IN'),
# MAGIC (144, 'SKU-144', 'Accessory BA', 'Accessories', 7, 14.50, 'IN'),
# MAGIC (145, 'SKU-145', 'Accessory BB', 'Accessories', 8, 15.50, 'IN'),
# MAGIC
# MAGIC (146, 'SKU-146', 'Widget BA', 'Widgets', 1, 165.00, 'US'),
# MAGIC (147, 'SKU-147', 'Gadget AN', 'Gadgets', 3, 145.00, 'US'),
# MAGIC (148, 'SKU-148', 'Accessory BC', 'Accessories', 2, 11.50, 'US'),
# MAGIC (149, 'SKU-149', 'Accessory BD', 'Accessories', 4, 13.75, 'US'),
# MAGIC (150, 'SKU-150', 'Widget BB', 'Widgets', 2, 170.00, 'US');
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC describe detail orders_managed_partitioned;

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW PARTITIONS orders_managed_partitioned;

# COMMAND ----------

# MAGIC %sql
# MAGIC select product_category, sum(qty) as total_qty
# MAGIC from orders_managed_partitioned
# MAGIC where country = 'IN'
# MAGIC group by product_category;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from orders_managed_partitioned;

# COMMAND ----------

# MAGIC %sql
# MAGIC select sum(qty) as total_qty_over_100
# MAGIC from orders_managed_partitioned
# MAGIC where unit_price > 100.0;

# COMMAND ----------

# MAGIC %sql
# MAGIC optimize orders_managed_partitioned;

# COMMAND ----------

# MAGIC %sql
# MAGIC select sum(qty) as total_qty_over_100
# MAGIC from orders_managed_partitioned
# MAGIC where unit_price > 100.0;

# COMMAND ----------

